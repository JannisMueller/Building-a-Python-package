import setuptools

setuptools.setup(
    name="number_guessing_game",
    version="0.5",
    author="Jannis Müller",
    author_email="jannis.mueller@hotmail.de",
    description="object-oriented package to play a number guessing game",
    zip_safe=False)
    
    
    


# TODO: Fill out this file with information about your package

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/